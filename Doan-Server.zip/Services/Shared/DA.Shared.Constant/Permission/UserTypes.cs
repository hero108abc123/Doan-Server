﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DA.Shared.Constant.Permission
{
    public class UserTypes
    {
        public const int Admin = 1;
        public const int Customer = 2;
    }
}
