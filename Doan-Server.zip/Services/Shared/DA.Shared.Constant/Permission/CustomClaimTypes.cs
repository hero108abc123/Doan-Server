﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DA.Shared.Constant.Permission
{
    public static class CustomClaimTypes
    {
        public const string UserType = "user_type";
    }
}
