﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DA.WebAPI.Controllers.Vehicle
{
    [Route("api/[controller]")]
    [ApiController]
    public class BusController : ControllerBase
    {
    }
}
