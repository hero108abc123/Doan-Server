﻿namespace DA.WebAPI.Body
{
    public class ExceptionBody
    {
        public string Message { get; set; }
    }
}
